package com.yuki.bigdata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataWarehouseApplicationTests {

    @Test
    void contextLoads() {
    }

}
